<p>You have registered successfully to Inter Earth Nexus. Click the link below to login.</p>

<a href="{{ route('login') }}">Login</a>
