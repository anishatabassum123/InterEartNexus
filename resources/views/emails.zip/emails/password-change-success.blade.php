<p>Your password has been updated successfully. Click the link below to login.</p>

<a href="{{ route('login') }}">Login</a>
